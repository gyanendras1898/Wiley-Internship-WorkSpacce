package com.piyush.presentation;

public interface EmployeePresentation {

	void showMenu();
	void performMenu(int choice);
}
