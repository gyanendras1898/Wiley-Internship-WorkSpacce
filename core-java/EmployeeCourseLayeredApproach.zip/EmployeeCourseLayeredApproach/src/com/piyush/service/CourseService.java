package com.piyush.service;

import com.piyush.beans.Course;
import com.piyush.beans.Employee;

public interface CourseService {

	Course[] getAllCoursesForEmployee();
	boolean registerEmployeeForCourse(String cId,Employee employee);
	boolean deregisterEmployeeForCourse(String cID,Employee employee);
	Employee[] listOfEmployeesForCourse(String cID);
}
