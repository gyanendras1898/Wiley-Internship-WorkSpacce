package com.piyush.service;

import com.piyush.beans.Employee;

public interface EmployeeService {

	Employee searchEmployeeById(int employeeId);
}
